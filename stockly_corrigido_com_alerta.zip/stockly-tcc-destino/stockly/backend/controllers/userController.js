const pool = require('../db');

// Função de Login
exports.login = async (req, res) => {
    const { email, senha } = req.body;
    try {
        const [rows] = await pool.query('SELECT * FROM usuarios WHERE email = ? AND senha = ?', [email, senha]);
        if (rows.length > 0) {
            // Retorna o primeiro usuário encontrado (deve ser único pelo email)
            const user = rows[0];
            // Remove a senha antes de enviar a resposta por segurança
            delete user.senha; 
            res.status(200).json(user);
        } else {
            res.status(401).json({ message: 'Credenciais inválidas' });
        }
    } catch (error) {
        console.error('Erro ao tentar login:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Obter todos os usuários
exports.getAllUsers = async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT id, nome, email, tipo, imagemUrl FROM usuarios');
        res.status(200).json(rows);
    } catch (error) {
        console.error('Erro ao obter usuários:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Obter usuário por ID
exports.getUserById = async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.query('SELECT id, nome, email, tipo, imagemUrl FROM usuarios WHERE id = ?', [id]);
        if (rows.length > 0) {
            res.status(200).json(rows[0]);
        } else {
            res.status(404).json({ message: 'Usuário não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter usuário por ID:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Criar novo usuário
exports.createUser = async (req, res) => {
    const { nome, email, senha, tipo, imagemUrl } = req.body;
    try {
        const [result] = await pool.query(
            'INSERT INTO usuarios (nome, email, senha, tipo, imagemUrl) VALUES (?, ?, ?, ?, ?)',
            [nome, email, senha, tipo, imagemUrl]
        );
        res.status(201).json({ id: result.insertId, nome, email, tipo, imagemUrl });
    } catch (error) {
        console.error('Erro ao criar usuário:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Atualizar usuário
exports.updateUser = async (req, res) => {
    const { id } = req.params;
    const { nome, email, senha, tipo, imagemUrl } = req.body;
    try {
        const [result] = await pool.query(
            'UPDATE usuarios SET nome = ?, email = ?, senha = ?, tipo = ?, imagemUrl = ? WHERE id = ?',
            [nome, email, senha, tipo, imagemUrl, id]
        );
        if (result.affectedRows > 0) {
            res.status(200).json({ id, nome, email, tipo, imagemUrl });
        } else {
            res.status(404).json({ message: 'Usuário não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar usuário:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Deletar usuário
exports.deleteUser = async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await pool.query('DELETE FROM usuarios WHERE id = ?', [id]);
        if (result.affectedRows > 0) {
            res.status(204).send();
        } else {
            res.status(404).json({ message: 'Usuário não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar usuário:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};
