const pool = require('../db');

// Obter todos os departamentos
exports.getAllDepartments = async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM departamentos');
        res.status(200).json(rows);
    } catch (error) {
        console.error('Erro ao obter departamentos:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Obter departamento por ID
exports.getDepartmentById = async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.query('SELECT * FROM departamentos WHERE id = ?', [id]);
        if (rows.length > 0) {
            res.status(200).json(rows[0]);
        } else {
            res.status(404).json({ message: 'Departamento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter departamento por ID:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Criar novo departamento
exports.createDepartment = async (req, res) => {
    const { nome } = req.body;
    try {
        const [result] = await pool.query(
            'INSERT INTO departamentos (nome) VALUES (?)',
            [nome]
        );
        res.status(201).json({ id: result.insertId, nome });
    } catch (error) {
        console.error('Erro ao criar departamento:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Atualizar departamento
exports.updateDepartment = async (req, res) => {
    const { id } = req.params;
    const { nome } = req.body;
    try {
        const [result] = await pool.query(
            'UPDATE departamentos SET nome = ? WHERE id = ?',
            [nome, id]
        );
        if (result.affectedRows > 0) {
            res.status(200).json({ id, nome });
        } else {
            res.status(404).json({ message: 'Departamento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar departamento:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Deletar departamento
exports.deleteDepartment = async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await pool.query('DELETE FROM departamentos WHERE id = ?', [id]);
        if (result.affectedRows > 0) {
            res.status(204).send();
        } else {
            res.status(404).json({ message: 'Departamento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar departamento:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};
