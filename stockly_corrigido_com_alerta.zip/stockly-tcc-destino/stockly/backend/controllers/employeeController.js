const pool = require('../db');

// Obter todos os funcionários
exports.getAllEmployees = async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT 
                f.id, f.nome_funcionario, f.cpf, f.telefone, f.email, f.cargo, f.fotoUrl,
                d.nome AS departamento_nome, f.departamento_id
            FROM funcionarios f
            LEFT JOIN departamentos d ON f.departamento_id = d.id
        `);
        res.status(200).json(rows);
    } catch (error) {
        console.error('Erro ao obter funcionários:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Obter funcionário por ID
exports.getEmployeeById = async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.query(`
            SELECT 
                f.id, f.nome_funcionario, f.cpf, f.telefone, f.email, f.cargo, f.fotoUrl,
                d.nome AS departamento_nome, f.departamento_id
            FROM funcionarios f
            LEFT JOIN departamentos d ON f.departamento_id = d.id
            WHERE f.id = ?
        `, [id]);
        if (rows.length > 0) {
            res.status(200).json(rows[0]);
        } else {
            res.status(404).json({ message: 'Funcionário não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter funcionário por ID:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Criar novo funcionário
exports.createEmployee = async (req, res) => {
    const { nome_funcionario, cpf, telefone, email, departamento_id, cargo, fotoUrl } = req.body;
    try {
        const [result] = await pool.query(
            'INSERT INTO funcionarios (nome_funcionario, cpf, telefone, email, departamento_id, cargo, fotoUrl) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [nome_funcionario, cpf, telefone, email, departamento_id, cargo, fotoUrl]
        );
        res.status(201).json({ id: result.insertId, nome_funcionario, cpf, telefone, email, departamento_id, cargo, fotoUrl });
    } catch (error) {
        console.error('Erro ao criar funcionário:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Atualizar funcionário
exports.updateEmployee = async (req, res) => {
    const { id } = req.params;
    const { nome_funcionario, cpf, telefone, email, departamento_id, cargo, fotoUrl } = req.body;
    try {
        const [result] = await pool.query(
            'UPDATE funcionarios SET nome_funcionario = ?, cpf = ?, telefone = ?, email = ?, departamento_id = ?, cargo = ?, fotoUrl = ? WHERE id = ?',
            [nome_funcionario, cpf, telefone, email, departamento_id, cargo, fotoUrl, id]
        );
        if (result.affectedRows > 0) {
            res.status(200).json({ id, nome_funcionario, cpf, telefone, email, departamento_id, cargo, fotoUrl });
        } else {
            res.status(404).json({ message: 'Funcionário não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar funcionário:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};

// Deletar funcionário
exports.deleteEmployee = async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await pool.query('DELETE FROM funcionarios WHERE id = ?', [id]);
        if (result.affectedRows > 0) {
            res.status(204).send();
        } else {
            res.status(404).json({ message: 'Funcionário não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar funcionário:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
};
