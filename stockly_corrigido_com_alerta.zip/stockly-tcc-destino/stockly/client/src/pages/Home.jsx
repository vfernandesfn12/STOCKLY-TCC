import { useListaProdutos } from "../hooks/UseProdutos";
import { Alert } from "react-bootstrap";
import { FaExclamationTriangle } from "react-icons/fa";

function Home() {
  const { produtosVencidos, produtosProximosVencimento } = useListaProdutos();

  const totalVencidos = produtosVencidos.length;
  const totalProximos = produtosProximosVencimento.length;

  const renderAlerta = () => {
    if (totalVencidos === 0 && totalProximos === 0) {
      return null;
    }

    let mensagem = "";
    let variant = "warning";

    if (totalVencidos > 0) {
      mensagem += `${totalVencidos} produto(s) vencido(s). `;
      variant = "danger";
    }

    if (totalProximos > 0) {
      mensagem += `${totalProximos} produto(s) próximo(s) do vencimento (próximos 7 dias).`;
      if (variant !== "danger") {
        variant = "warning";
      }
    }

    return (
      <Alert variant={variant} className="mt-3">
        <FaExclamationTriangle className="me-2" />
        <strong>ALERTA DE ESTOQUE:</strong> {mensagem}
        <div className="mt-2">
          <small>
            Verifique a página de Produtos para mais detalhes.
          </small>
        </div>
      </Alert>
    );
  };
  
  return (
    <div className="container">
      <h1>HOME</h1>
      {renderAlerta()}
      {/* Aqui você pode adicionar o restante do conteúdo da sua Home */}
    </div>
  );
}

export default Home;
