// url da API
const url = import.meta.env.VITE_API_URL;

//Importando o hook de useState para controlar as variáveis
import { useState, useEffect } from "react";

export function useListaCategorias() {
  // Variável para armazenar as categorias
  const [categorias, setCategorias] = useState([]);
  //Puxa os dados da API assim que o componente é iniciado
  useEffect(() => {
    async function fetchCategorias() {
      try {
        // Fetch abre conexão com a api, na rota específicada e guarda o resposta em req
        const req = await fetch(`${url}/categorias`);
        // Como a resposta vem em texto, preciso converter para json para utilizar
        const res = await req.json();
        // Assim que tiver convertido, guarda na variável criada para guardar as categorias
        setCategorias(res);
      } catch (erro) {
        // Se tiver erro no tentativa de conexão com a api, mostrar qual foi no console
        console.log(erro.message);
      }
    }
    // Executa a função de buscar as categorias na api
    fetchCategorias();
  }, []);
  // retorna pra quem chamou a função, a lista de categorias já preenchida
  return categorias;
}

export function useListaMedidas() {
  // lista com medidas
  const [medidas] = useState([
    { id: 1, nome: "mL" },
    { id: 2, nome: "L" },
  ]);
  return medidas;
}

// CRUD PRODUTOS

// C
export function useInserirProduto() {
  // Recebe os dados vindo do formulário, faz uma requisição pra API, pra inserção do produto
  // Utilizando o verdo POST
  const inserirProduto = async (data) => {
    const req = await fetch(`${url}/produtos`, {
      method: "POST",
      headers: { "Content-type": "application/json" },
      body: JSON.stringify(data),
    });
    const res = await req.json();
    console.log("Produto inserido:", res);

    //Retornar o produto inserido
    return res;
  };

  return { inserirProduto };
}

// R
export function useListaProdutos() {
  //Lista de produtos
  const [produtos, setProdutos] = useState([]);
  // UseEffect pra puxar os dados da API assim que o componente é renderizado
  
  // Variáveis para armazenar produtos com alerta
  const [produtosVencidos, setProdutosVencidos] = useState([]);
  const [produtosProximosVencimento, setProdutosProximosVencimento] = useState([]);

  // Função para verificar a data de vencimento
  const verificarVencimento = (produtos) => {
    const hoje = new Date();
    // Define o limite de 7 dias para "próximo do vencimento"
    const proximaSemana = new Date();
    proximaSemana.setDate(hoje.getDate() + 7);

    const vencidos = [];
    const proximos = [];

    produtos.forEach(produto => {
      if (produto.dataVencimento) {
        const dataVencimento = new Date(produto.dataVencimento);
        // Ajusta a data de vencimento para o final do dia para comparação correta
        dataVencimento.setHours(23, 59, 59, 999); 

        if (dataVencimento < hoje) {
          vencidos.push(produto);
        } else if (dataVencimento <= proximaSemana) {
          proximos.push(produto);
        }
      }
    });

    setProdutosVencidos(vencidos);
    setProdutosProximosVencimento(proximos);
  };

  useEffect(() => {
    async function fetchData() {
      try {
        const req = await fetch(`${url}/produtos`);
        const res = await req.json();
        setProdutos(res);
        verificarVencimento(res); // Chama a verificação após buscar os dados
      } catch (error) {
        console.log(error.message);
      }
    }
    fetchData();
  }, []);

  // Retorna a lista de produtos, produtos vencidos e produtos próximos do vencimento
  return { produtos, produtosVencidos, produtosProximosVencimento };
}

// D - Deletar
export function useDeletaProduto() {
  // Recebe o id do produto e requisita a api a exclusão
  const deletarProduto = async (idProduto) => {
    const req = await fetch(`${url}/produtos/${idProduto}`, {
      method: "DELETE",
    });
    // O backend retorna 204 (No Content) para DELETE bem-sucedido, sem corpo JSON.
    if (req.status === 204) {
      return true;
    }
    // Se houver corpo JSON (ex: erro), tenta ler.
    try {
      const res = await req.json();
      return res;
    } catch (e) {
      return false;
    }
  };

  return { deletarProduto };
}

// U - Atualizar
// Hook para buscar informações de um produto específico
export function useBuscarProdutoPorId() {
  // Recebe o id do produto e busca as informações
  const buscarProdutoPorId = async (idProduto) => {
    const req = await fetch(`${url}/produtos/${idProduto}`);
    const res = await req.json();
    console.log("Produto encontrado:", res);
    return res;
  };
  return { buscarProdutoPorId };
}

// Hook para atualizar um produto
export function useAtualizarProduto() {
  // Envia os dados novos, para o produto específico
  const atualizarProduto = async (data, idProduto) => {
    const req = await fetch(`${url}/produtos/${idProduto}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const res = await req.json();
    return res;
  };
  return { atualizarProduto };
}
