-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS stockly_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Criação do usuário e concessão de privilégios (para uso no sandbox)
CREATE USER IF NOT EXISTS 'stockly_user'@'localhost' IDENTIFIED BY 'stockly_password';
GRANT ALL PRIVILEGES ON stockly_db.* TO 'stockly_user'@'localhost';
FLUSH PRIVILEGES;

-- Seleciona o banco de dados
USE stockly_db;

-- Tabela: departamentos
CREATE TABLE IF NOT EXISTS departamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL UNIQUE
);

-- Tabela: categorias
CREATE TABLE IF NOT EXISTS categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL UNIQUE
);

-- Tabela: usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('Administrador', 'Gerente', 'Funcionário') NOT NULL,
    imagemUrl VARCHAR(512)
);

-- Tabela: funcionarios
CREATE TABLE IF NOT EXISTS funcionarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_funcionario VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    telefone VARCHAR(20),
    email VARCHAR(255) UNIQUE,
    departamento_id INT,
    cargo VARCHAR(255),
    fotoUrl VARCHAR(512),
    FOREIGN KEY (departamento_id) REFERENCES departamentos(id)
);

-- Tabela: produtos (estrutura básica, será refinada se necessário)
CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10, 2),
    quantidade INT,
    categoria_id INT,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

-- Limpar dados existentes para evitar duplicatas
DELETE FROM funcionarios;
DELETE FROM usuarios;
DELETE FROM produtos;
DELETE FROM categorias;
DELETE FROM departamentos;

-- Inserção de dados iniciais (baseado em db.json) - CORRIGIDO

-- Departamentos
INSERT INTO departamentos (nome) VALUES ('RH');

-- Categorias
INSERT INTO categorias (nome) VALUES ('Saúde e Beleza');

-- Usuários (CORRIGIDO: "Administrador" ao invés de "Admnistrador")
INSERT INTO usuarios (nome, email, senha, tipo, imagemUrl) VALUES
('Administrador', 'admin@gmail.com', '123', 'Administrador', 'https://i.ytimg.com/vi/mMxBYLbyWLw/hq2.jpg?sqp=-oaymwEoCOADEOgC8quKqQMcGADwAQH4AYYCgALgA4oCDAgAEAEYRyBLKHIwDw==&rs=AOn4CLC1G7W20xNWxDV1ozQlQe2Tyns_5g'),
('Gerente', 'gerente18@gmail.com', '123', 'Gerente', 'https://i.pinimg.com/736x/c5/ff/57/c5ff57e4b118ef87bae340068123cbe7.jpg'),
('Funcionário', 'funcionario@gmail.com', '12', 'Funcionário', 'https://i.pinimg.com/736x/b2/79/44/b2794415016ee72dcf75fdc904a3c7f5.jpg');

-- Funcionários (Assumindo que 'RH' tem id=1)
INSERT INTO funcionarios (nome_funcionario, cpf, telefone, email, departamento_id, cargo, fotoUrl) VALUES
('Joao', '175.784.637-99', '27995026326', 'joao@gmail.com', 1, NULL, 'https://s2-galileu.glbimg.com/uNEmxS89cbcamZwvIpRCkWquGwI=/0x0:1386x888/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_fde5cd494fb04473a83fa5fd57ad4542/internal_photos/bs/2023/m/e/F8xdjfQDGBUXCLqg7oMw/21.jpg'),
('Jubscreudi', '178.854.684-99', '2799856326', 'jubscreudi@gmail.com', 1, 'Assistente', 'https://th.bing.com/th/id/R.2196f16c9be19ff73c37d70bbc6b0b0a?rik=cPkgcXn%2bxRqrXQ&pid=ImgRaw&r=0'),
('Marcos', '845.687.987-22', '27995026326', 'marcosvinicius@gmail.com', 1, 'Auxiliar', 'https://tse3.mm.bing.net/th/id/OIP.z2gsKlG9_QisRa7O6paelAHaEK?rs=1&pid=ImgDetMain&o=7&rm=3');
