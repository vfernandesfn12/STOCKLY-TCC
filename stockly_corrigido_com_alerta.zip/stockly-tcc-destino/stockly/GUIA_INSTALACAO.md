# 🚀 Guia Rápido de Instalação - Sistema Stockly

## Pré-requisitos

- Node.js (v14 ou superior)
- MySQL Server (v8.0 ou superior)
- npm ou yarn

---

## 📦 Passo 1: Instalar MySQL

### Ubuntu/Debian:
```bash
sudo apt-get update
sudo apt-get install mysql-server
sudo systemctl start mysql
sudo systemctl enable mysql
```

### Windows:
Baixe e instale o MySQL Community Server de: https://dev.mysql.com/downloads/mysql/

### macOS:
```bash
brew install mysql
brew services start mysql
```

---

## 🗄️ Passo 2: Configurar o Banco de Dados

```bash
# Acesse o diretório do projeto
cd stockly

# Execute o script SQL
sudo mysql < setup_db_fixed.sql

# OU, se precisar de senha:
mysql -u root -p < setup_db_fixed.sql
```

**Verificar se funcionou**:
```bash
sudo mysql -e "USE stockly_db; SELECT * FROM usuarios;"
```

Você deve ver 3 usuários cadastrados.

---

## 🔧 Passo 3: Configurar o Backend

```bash
# Entre no diretório do backend
cd backend

# Instale as dependências
npm install

# Verifique o arquivo .env (já está configurado)
cat .env

# Inicie o servidor
node server.js
```

**Saída esperada**:
```
Servidor rodando na porta 5000
```

**Testar o backend**:
```bash
curl -X POST http://localhost:5000/api/usuarios/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@gmail.com","senha":"123"}'
```

---

## 🎨 Passo 4: Configurar o Frontend

```bash
# Entre no diretório do client (em outro terminal)
cd client

# Instale as dependências
npm install

# Inicie o servidor de desenvolvimento
npm run dev
```

**Saída esperada**:
```
VITE v7.1.9  ready in XXX ms
➜  Local:   http://localhost:5173/
➜  Network: http://xxx.xxx.xxx.xxx:5173/
```

---

## 🌐 Passo 5: Acessar a Aplicação

Abra seu navegador e acesse:
```
http://localhost:5173
```

### Credenciais de Login:

**Administrador**:
- Email: `admin@gmail.com`
- Senha: `123`

**Gerente**:
- Email: `gerente18@gmail.com`
- Senha: `123`

**Funcionário**:
- Email: `funcionario@gmail.com`
- Senha: `12`

---

## 🔍 Solução de Problemas

### Erro: "Cannot connect to MySQL"
```bash
# Verifique se o MySQL está rodando
sudo systemctl status mysql

# Se não estiver, inicie:
sudo systemctl start mysql
```

### Erro: "Port 5000 already in use"
```bash
# Encontre o processo usando a porta
lsof -i :5000

# Mate o processo
kill -9 <PID>
```

### Erro: "Port 5173 already in use"
```bash
# Encontre o processo usando a porta
lsof -i :5173

# Mate o processo
kill -9 <PID>
```

### Erro: "Module not found"
```bash
# Reinstale as dependências
cd backend && rm -rf node_modules && npm install
cd ../client && rm -rf node_modules && npm install
```

---

## 📁 Estrutura do Projeto

```
stockly/
├── backend/
│   ├── controllers/      # Lógica de negócio
│   ├── routes/          # Rotas da API
│   ├── db.js            # Conexão com banco
│   ├── server.js        # Servidor Express
│   ├── .env             # Variáveis de ambiente
│   └── package.json
├── client/
│   ├── src/
│   │   ├── components/  # Componentes React
│   │   ├── contexts/    # Context API
│   │   ├── hooks/       # Custom hooks
│   │   ├── pages/       # Páginas da aplicação
│   │   └── App.jsx
│   ├── vite.config.js
│   └── package.json
├── setup_db_fixed.sql   # Script do banco de dados
├── RELATORIO_CORRECOES.md
└── GUIA_INSTALACAO.md
```

---

## 🔐 Segurança (Importante!)

⚠️ **ATENÇÃO**: Este projeto está configurado para desenvolvimento/demonstração.

Para uso em produção, você DEVE:

1. **Criptografar senhas** com bcrypt
2. **Implementar JWT** para autenticação
3. **Usar HTTPS** ao invés de HTTP
4. **Proteger variáveis de ambiente**
5. **Adicionar validação de entrada**
6. **Implementar rate limiting**
7. **Configurar CORS adequadamente**

---

## 📞 Suporte

Se encontrar problemas:

1. Verifique o `RELATORIO_CORRECOES.md` para detalhes das correções
2. Verifique os logs do backend: `backend/server.log`
3. Verifique os logs do frontend: `client/client.log`
4. Verifique o console do navegador (F12)

---

## ✅ Checklist de Instalação

- [ ] MySQL instalado e rodando
- [ ] Banco de dados criado (`setup_db_fixed.sql` executado)
- [ ] Backend instalado (`npm install` no diretório backend)
- [ ] Backend rodando (porta 5000)
- [ ] Frontend instalado (`npm install` no diretório client)
- [ ] Frontend rodando (porta 5173)
- [ ] Login funcionando com credenciais de teste

---

**Boa sorte! 🎉**
